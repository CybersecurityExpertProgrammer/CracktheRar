#!/usr/bin/python
# coding: Latin-1
import os, sys


#
##################################################
######## Youtube channel: https://www.youtube.com/channel/UCOrau48ywR0gaiieATAIZTA#########
############### Susbcribe our channel and share with your friends###########################
##################################################
#
#
__author__='''
     
  

################################################################################
                                                                               #          
                                                                               #          
                                                                               #
 █████╗ ███╗   ███╗ █████╗ ██████╗     ██╗  ██╗██╗  ██╗ █████╗ ███╗   ██╗      #
██╔══██╗████╗ ████║██╔══██╗██╔══██╗    ██║ ██╔╝██║  ██║██╔══██╗████╗  ██║      #
███████║██╔████╔██║███████║██║  ██║    █████╔╝ ███████║███████║██╔██╗ ██║      #
██╔══██║██║╚██╔╝██║██╔══██║██║  ██║    ██╔═██╗ ██╔══██║██╔══██║██║╚██╗██║      #
██║  ██║██║ ╚═╝ ██║██║  ██║██████╔╝    ██║  ██╗██║  ██║██║  ██║██║ ╚████║      #
╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═════╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝      #                                                                             
                                                                               #
****************************************************************************** #
                                                                               #
                      Telegram: +923119647606                                  # 
                                                                               #
                      Whatsapp: +923119647606                                  #
                                                                               #
Youtube: Channel https://www.youtube.com/channel/UCOrau48ywR0gaiieATAIZTA      #
                                                                               #
         Cradit goes to Amadkhan(Cyber Security Reseacher and Student          #                                                                            
################################################################################                                                                        
                                                                                                                                  
   
    
'''

# =================setup================ 
# Usages :
usage = "usage: %prog [Commond/Option] "
# Version
Version="%prog 0.0.1"
# ====================================================
print __author__
 
# Import Modules
import rarfile,optparse,sys,fileinput,time

class main:
	def __init__(self):
		self.extract_input_data()
		self.check_input_conditions()
		self.start_cracking_engine()

	def time_management(self):
		print "[*]	Starting Time ",self.starttime
		print "[*]	Closing  Time ",self.closetime
		print "[*]	Password Try  ",self.pwdtries
		print "[*]	Average Speed ",self.pwdtries/(self.closetime-self.starttime)
		return

	def start_cracking_engine(self):
		print "[+]	Loading rarfile...  ",
		fileload=rarfile.RarFile(self.filename)
		print "OK"
		if self.dictionary:
			print "[+]	Dictionary option .... OK"
			print "[+]      Dictonary File...  OK"
			print "[+]	Cracking proccess started ..."
			for i in fileinput.input(self.dictionary):
				pwd=i.strip('\n')
				self.extracting_engine(fileload,pwd)
		if self.crunch:
			print "[+] Connection Stablished as Pipe... OK"
			print "[+]	Cracking process is started ..."
			for i in sys.stdin:
				pwd=i.strip('\n')
				self.extracting_engine(fileload,pwd)
		self.show_info_message()

		return

	def check_input_conditions(self):
		if not self.filename:
			print "[ Error ] Please Enter your Rar file "
			sys.exit(0)
		print "[+]	Rar file checking ...",
		if not rarfile.is_rarfile(self.filename):
			print "[ Error ] Not found any Rar file"
			sys.exit(0)
		print "	Ok"

		if not self.dictionary and not self.crunch:
			print "[ Error ] Enter your correct wordlist and its location"
			sys.exit(0)
		if self.dictionary and self.crunch:
			print "[ Error ] Please Enter your Correct wordlist in order to crack perfectly"
			sys.exit(0)
		return

	def extracting_engine(self,file,pwd):
		self.pwdresult=None
		try:
			file.extractall(self.output,pwd=str(pwd))
			self.show_info_message(pwd=pwd)
			self.pwdresult=True
		except Exception as e:
			if str(e).find('Permission')!=-1:
				self.show_info_message(pwd=pwd)
				self.pwdresult=True
			else:
				self.pwdresult=None
		self.pwdtries=self.pwdtries+1

		return 

		

	def show_info_message(self,pwd=None):
		if pwd:
			data="\n\t Wow your Rar file is cracked successfully!. Cradits goes to Amadkhan  \n\t\tCracked password done = "+pwd+'\n'
		else:
			data="\n\t Oh! Password not found  \n\n"
		print data
		if self.result:
			print "[+] Your Crack password is stored  in result.txt file ",self.result
			f=open(self.result,'a')
			f.write(data)
			f.close()
		self.closetime=time.time()
		self.time_management()
		if pwd:
			print "[+] Exiting..."
			sys.exit(0)
		return

	def extract_input_data(self):
		self.starttime=time.time()
		self.pwdtries=0
		# Extracting Function
		parser = optparse.OptionParser(usage, version=Version)
		parser.add_option("-f", "--file", action="store", type="string", dest="filename",help="To put your Rar file name and its path", default=None)
		parser.add_option("-d", "--dict", action="store", type="string", dest="dictionary", help="To put your wordlist/Dictionary and its path", default=None)
		parser.add_option("-o", "--output", action="store", type="string", dest="output", help="path for Extracting", default='.')
		parser.add_option("-r", "--result", action="store", type="string", dest="result", help="To Put your output cracking result file name and its path", default=None)
		parser.add_option("-c", "--crunch", action="store", type="string", dest="crunch", help="To use Huge wordlists/Dictionary directly from Cruch arguments: -c True or --crunch True", default=None)
		(option, args)=parser.parse_args()
		# Record Inputs Data
		print "[+] Extracting Input Data..."
		self.filename=option.filename
		self.dictionary=option.dictionary
		self.output=option.output
		self.result=option.result
		self.crunch=option.crunch
		return

if __name__ == '__main__':
	main()
